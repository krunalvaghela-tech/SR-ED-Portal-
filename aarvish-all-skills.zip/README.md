# Project skills

Design skills Claude Code loads automatically when working in this repository.

| Skill | Source | Commit |
|---|---|---|
| `landing-page-design` | <https://github.com/elayadesign/ai-design-skills> | `456d9e0d3e2d84c748bb143c6ca3d90c45e16213` |
| `figma-designer` | <https://github.com/elayadesign/ai-design-skills> | `456d9e0d3e2d84c748bb143c6ca3d90c45e16213` |
| `apple-design` | <https://github.com/dickwu/apple-design-skill> | `91e15664896f6f27e75dcf1414d1226cb95fa167` |
| `ui-ux-pro-max` | <https://github.com/nextlevelbuilder/ui-ux-pro-max> | v2.15.0 |
| `design-system` | <https://github.com/nextlevelbuilder/ui-ux-pro-max> | v2.15.0 |

The two elayadesign skills are MIT licensed (copyright Elaya) and copied here
unmodified. `ui-ux-pro-max` and `design-system` are MIT licensed sub-skills of
ui-ux-pro-max, taken as they are in the KV WebDesign repository (test suites
and caches stripped there); the search tool is a local CSV lookup with no
network access: `python3 .claude/skills/ui-ux-pro-max/scripts/search.py "<query>" --domain ux`.
`apple-design` carries no licence of its own and its guideline text belongs to
Apple Inc. To update a skill, replace its folder and change the row above.

This folder is for Claude Code only. It is not part of the website and is not
uploaded to the server.
